package Logic;

import Front.Estructura;

/*
 * @autores Cinefilos de EDA 
 */
public class main {

    public static void main(String[] args) {
        Estructura est = new Estructura();
        est.setVisible(true);
    }
}
